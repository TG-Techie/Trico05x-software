import time
import os

from TG_Modules.TG_GUI import gui
from TG_Modules.make_ios import dio
import board

print('gui')

from staging.disp import disp,color
print('disp')

disp.fill(color(255,255,255))
disp.fill(0)

#global nav
try:
    from programs.start import nav
except ImportError:
    pass
try:
    import gamepad

    nav = gamepad.GamePad(dio(board.A5,1),dio(board.A4,1),dio(board.A3,1))
    while False:
        print(nav.get_pressed())
        time.sleep(1)#
except ValueError:
    pass



from staging.sen_brd import amg

def launch_ir_cam(thing):
        time.sleep(.1)
        
        flick = 0
        
        disp.rect(0,0,disp.width, disp.height, 0)
        x = 0
        y = 0
        border = 5
        width = int((128-(border*2))/8)
        
        info = (amg.pixels)
        graph_width = len(info)
        graph_height = len(info[0])
            
        disp.rect(x, y, (border*2)+(graph_width*width),
                    (border*2)+(graph_height*width), color(5,85,110))
        
        top_val = 30
        while True:
            
                
            info = (amg.pixels)
            
            global cur_top_val
            cur_top_val = 0
            
            
            for y_pos in (range(len(info))):
                for x_pos in range(len(info[0])):
                    #print('-----------------')
                    #print(info[y_pos][x_pos])
                    #print(int(color(255,255,255)*info[y_pos][x_pos]/100))
                    #time.sleep(.005)
                    global cur_top_val
                    temp = info[x_pos][y_pos]
                    cur_top_val = max(cur_top_val,temp)
                    #print(top_val, cur_top_val)
                    scale = info[x_pos][y_pos]/(1+max(top_val, cur_top_val))
                    foo = (int(scale*255))
                    disp.rect(border+x+(graph_width-x_pos-1)*width, border+y+y_pos*width, 
                                width, width, color(foo,foo,foo))
            
            top_val = cur_top_val
            if (nav.get_pressed()&2) and (flick):
                thing.place()
                break
            flick = 1

nfp_func = 5
def not_filled_page():
    disp.fill(color(255,0,0))
    disp.text(0,0,'this button has no purpose yet, this is because it has not been set yet',color = 0,background = color(255,0,0))
    for i in range(20):
        if nav.get_pressed() & 2:
            break
        time.sleep(2/20)
    nav.get_pressed()
    time.sleep(.25)
    try:
        nfp_func.place()
    except AttributeError:
        pass

#not_filled_page()

if True :
    print('starting nidos example')
    #n = gui.nidos(0,0,disp.width,disp.height,3,4,5,5, gui.text_button,
    #(10,10, 30, 25, 3,'', not_filled_page,(), 0, place = 0, output = 0))
    '''n = gui.nidos(0,0,disp.width,disp.height,3,4,5,5,gui.text_button,
            (10,10, 30, 25, 3,'', disp.fill, (color(255,0,0))), 0,place = 0, output = 0)'''
    n = gui.nidos(0,0,disp.width,disp.height,3,4,5,5,gui.text_button,
            (10,10, 30, 25, 3,'', not_filled_page, ()  ), 3,place = 0, output = 0)
    print('nidos placed')
    nfp_func = n
    
    def exp_func():
        disp.fill(0)
        disp.text(0,0,'button pressed',color(255,255,255))
        time.sleep(1)
        disp.text(0,10,'yay!',color(255,255,255))
        n.move(0,1)
        n.click()
        time.sleep(1)
        n.place()
        return
    
    n.of(0,-1).change_text("""wipe""", place = 0)
    n.of(0,-1).repurpose(exp_func, () )
    
    
    def exp_end_loop():
        disp.fill(0)
        disp.text(0,0,'program ended')
        time.sleep(3)
        disp.fill(0)
    n.of(-1,-1).change_text("""quit""", place = 0)
    n.of(-1,-1).repurpose(exp_end_loop, () )
    
    def prog_ir (thing):
        disp.fill(0)
        from programs import therm_cam_dev
    
    n.of(1,2).change_text("""start
IRCam""", place = 0)
    n.of(1,2).repurpose(prog_ir, (n) )
    
    n.place()
        
    print('text and functions changed')
    time.sleep(1)
    
    #n.move(1,0)
    
    #n.move(1,0)
    #time.sleep(1)
    
    #n.move(1,0)
    #time.sleep(1)
    global command
    command = ''
    
    val = 0
    while val != 7:
        
        val = nav.get_pressed()
        time.sleep(.35)
        if val&2:
            nav.get_pressed()
            (n.click())
        elif val&1:
            nav.get_pressed()
            (n.move(1,0))
        elif val&4:
            nav.get_pressed()
            (n.move(0,1))
        else:
            continue
        time.sleep(.25)
        
    
    
    '''while command != 'quit':
        command = (input('give an arrow command:')).lower().replace(' ','')
        if command == 'place':
            n.place()
        if command == 'r':
            print('moved: ',n.move(1,0))
        elif command == 'l':
            print('moved: ',n.move(-1,0))
        elif command == 'd':
            print('moved: ',n.move(0,1))
        elif command == 'u':
            print('moved: ',n.move(0,-1))
        elif command == 'e':
            print(n.click())
        else:
            print('command not recognised')'''
   
   
    
    print('done with nidos example')




if True:
    print('starting button example')
    disp.fill(color(255,0,255))
    disp.fill(0)
    time.sleep(1)

    t = gui.text_button(10,10, 30, 20, 0,'test', disp.fill, (color(255,0,0)))
    print('button created')
    time.sleep(1)

    t.place()
    print('placed')
    time.sleep(1)
    
    t.clear()
    time.sleep(1)

    t.select()
    time.sleep(1)

    t.relocate(50,50, place = 1, implement = 1)
    time.sleep(1)
    

    t.change_text("new?", -2,2)
    print('text_changed')
    time.sleep(1)

    t.recolor(color = color(0,172,0), text_color = 0, color_sel = color(0,255,0))
    print('color and text changed')
    time.sleep(1)

    t.deselect()
    time.sleep(1)

    t.repurpose(disp.fill,color(0,252,0))
    time.sleep(1)

    t.reshape(50,50,7)
    t.place()
    time.sleep(1)
    
    t.clear()
    time.sleep(1)
    
    t.select()
    time.sleep(1)
    
    t.press()
    print('pressed')
    time.sleep(4)

    print('done button example')