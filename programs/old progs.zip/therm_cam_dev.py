from middle import screen

tg = screen.thermal_graph(10,10, 10, 3)

tg.place

while True:
    tg.update()