from middle import screen
import time

screen.io.fill(0)

g = screen.thermal_graph(10,10,10,3)

#g.place()

time.sleep(1)

from programs.start import nav

while True:
    val = nav.get_pressed()
    if val&5:
        g.update()
        nav.get_pressed()
        time.sleep(.15)
        
time.sleep(2)