from tg_modules.tg_gui import gui
import time
gui.io.fill(0)
gui.io.fill(gui.io.color(255,255,255))

p = gui.page(0,10,50,50,1 , 4, 3,3, splitx_start = 80)

time.sleep(7)