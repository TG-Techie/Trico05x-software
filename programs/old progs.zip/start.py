import time
from staging.disp import disp,color
from tg_modules.tg_gui import gui
from tg_modules.make_ios import dio
import board
global nav


import gamepad
try:
    nav = gamepad.GamePad(dio(board.A5,1),dio(board.A4,1),dio(board.A3,1))
except ValueError:
    pass


nfp_func = 5
def not_filled_page():
    disp.fill(color(255,0,0))
    disp.text(0,0,'this button has no purpose yet, this is because it has not been set yet',color = 0,background = color(255,0,0))
    for i in range(20):
        if nav.get_pressed() & 2:
            break
        time.sleep(2/20)
    time.sleep(.25)
    nav.get_pressed()
    try:
        nfp_func.place()
    except AttributeError:
        pass

n = gui.nidos(0,0,disp.width,disp.height,1,5,5,5,gui.text_button,
            (10,10, 30, 25, 3,'', not_filled_page, () ), 0,place = 0, output = 0)
nfp_func = n

def launch_menus_exp():
    import programs.menu_example
    
n.of(0,0).repurpose(launch_menus_exp, ())
n.of(0,0).change_text('menu exp.', x_offset = -25, place = 0)

def therm_dev():
    import programs.therm_cam_dev
    
n.of(0,1).repurpose(therm_dev,())
n.of(0,1).change_text('therm cam dev', x_offset = -15, place = 0)



def send_control():
    n.place()
    val = 0
    while val != 7:
            val = nav.get_pressed()
            time.sleep(.35)
            if val&2:
                (n.click())
            elif val&1:
                (n.move(0,-1))
            elif val&4:
                (n.move(0,1))
            else:
                continue
            time.sleep(.1)

send_control()