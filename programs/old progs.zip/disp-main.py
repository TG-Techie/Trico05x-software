from Middle.boot import *

#disp.text(0,0,"abcdefghi", background  = color(0,0,255))

disp.text(0,0,"""he who wish to cross the bridge of death must answer me these questions three ere the other side he see""",
          background = 0,color  = color(255,255,255),
          rect_extension = 0)
time.sleep(5)
